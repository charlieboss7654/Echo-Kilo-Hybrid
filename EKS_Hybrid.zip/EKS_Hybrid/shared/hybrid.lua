Config = {}

Config.useKmh = false

Config.CheckInterval = 300

Config.HybridVehicles = {
    {
        model = "asbo",
        upSwitchSpeed = 40.0,     -- go GAS over this
        downSwitchSpeed = 32.0,   -- go ELECTRIC under this
        electricHash = "AIRTUG",
        gasHash = "ASBO",
    },
    {
        model = "tesla",
        upSwitchSpeed = 35.0,
        downSwitchSpeed = 28.0,
        electricHash = "AIRTUG",
        gasHash = "ELEGY",
    },
}
