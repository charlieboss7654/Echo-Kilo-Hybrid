local VEH_CONFIGS = {}
local currentMode = {}   
local lastVeh = nil

CreateThread(function()
    for _, v in ipairs(Config.HybridVehicles) do
        VEH_CONFIGS[joaat(v.model)] = {
            up = v.upSwitchSpeed,
            down = v.downSwitchSpeed,
            eHash = v.electricHash,
            gHash = v.gasHash
        }
    end
end)

local function vehSpeed(v)
    if not DoesEntityExist(v) then return 0.0 end
    local mps = GetEntitySpeed(v)
    if Config.useKmh then
        return mps * 3.6
    else
        return mps * 2.236936
    end
end

local function ensureInitialElectric(veh, cfg)
    if currentMode[veh] == nil then
        ForceVehicleEngineAudio(veh, cfg.eHash)
        currentMode[veh] = "electric"
    end
end

local function handleHybrid(veh, cfg)
    ensureInitialElectric(veh, cfg)

    local spd = vehSpeed(veh)
    local mode = currentMode[veh]

     if mode == "electric" and spd > cfg.up then
        ForceVehicleEngineAudio(veh, cfg.gHash)
        currentMode[veh] = "gas"
    elseif mode == "gas" and spd < cfg.down then
        ForceVehicleEngineAudio(veh, cfg.eHash)
        currentMode[veh] = "electric"
    end
end

CreateThread(function()
    while true do
        Wait(Config.CheckInterval)

        local ped = PlayerPedId()
        if not IsPedInAnyVehicle(ped, false) then
            if lastVeh and currentMode[lastVeh] ~= nil then
                currentMode[lastVeh] = nil
            end
            lastVeh = nil
        else
            local veh = GetVehiclePedIsIn(ped, false)
            lastVeh = veh

            if GetPedInVehicleSeat(veh, -1) == ped then
                local hash = GetEntityModel(veh)
                local cfg = VEH_CONFIGS[hash]
                if cfg then
                    handleHybrid(veh, cfg)
                else
                    if currentMode[veh] ~= nil then
                        currentMode[veh] = nil
                    end
                end
            end
        end
    end
end)
