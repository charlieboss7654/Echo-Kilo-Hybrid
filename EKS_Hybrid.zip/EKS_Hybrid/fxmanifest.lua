fx_version 'cerulean'
game 'gta5'

author 'Cowboy - Echo Kilo Studios'
description 'Hybrid Engine Script by Echo Kilo Studios'
version '1.0.0'

client_script 'client/main.lua'
shared_script 'shared/hybrid.lua'
